import fs from 'fs/promises';
import path from 'path';
import sharp from 'sharp';

const OUTPUT_DIR = 'public/images';
const SIZES = {
  thumbnail: 200,
  small: 400,
  medium: 800,
  large: 1200
};

async function ensureDir(dir) {
  try {
    await fs.mkdir(dir, { recursive: true });
  } catch (error) {
    if (error.code !== 'EEXIST') throw error;
  }
}

async function saveAndOptimizeImage(inputBuffer, baseName) {
  await ensureDir(OUTPUT_DIR);
  
  const optimizedImages = {};
  
  // Process each size
  for (const [sizeName, width] of Object.entries(SIZES)) {
    const outputPath = path.join(OUTPUT_DIR, `${baseName}-${sizeName}.webp`);
    
    await sharp(inputBuffer)
      .resize(width, null, {
        withoutEnlargement: true,
        fit: 'cover'
      })
      .webp({ quality: 80 })
      .toFile(outputPath);
      
    optimizedImages[sizeName] = `/images/${baseName}-${sizeName}.webp`;
  }
  
  return optimizedImages;
}

// Example usage:
const imageBuffer = await fs.readFile('path/to/your/image.jpg');
const optimizedPaths = await saveAndOptimizeImage(imageBuffer, 'team-therapist');
console.log('Optimized image paths:', optimizedPaths);