import sharp from 'sharp';
import fs from 'fs/promises';
import path from 'path';

const IMAGE_SIZES = {
  thumbnail: 200,
  small: 400,
  medium: 800,
  large: 1200
};

const INPUT_DIR = 'src/assets/images';
const OUTPUT_DIR = 'public/images';
const QUALITY = 80;

async function ensureDir(dir) {
  try {
    await fs.mkdir(dir, { recursive: true });
  } catch (error) {
    if (error.code !== 'EEXIST') throw error;
  }
}

async function optimizeImage(inputPath, baseName, size) {
  const outputPath = path.join(OUTPUT_DIR, `${baseName}-${size}.webp`);
  
  await sharp(inputPath)
    .resize(IMAGE_SIZES[size], null, {
      withoutEnlargement: true,
      fit: 'cover'
    })
    .webp({ quality: QUALITY })
    .toFile(outputPath);
    
  console.log(`Generated ${size} version: ${outputPath}`);
  return outputPath;
}

async function processImages() {
  try {
    await ensureDir(OUTPUT_DIR);
    
    const files = await fs.readdir(INPUT_DIR);
    
    for (const file of files) {
      if (!file.match(/\.(jpg|jpeg|png|webp)$/i)) continue;
      
      const inputPath = path.join(INPUT_DIR, file);
      const baseName = path.parse(file).name;
      
      console.log(`Processing ${file}...`);
      
      // Process all sizes in parallel
      await Promise.all(
        Object.keys(IMAGE_SIZES).map(size => 
          optimizeImage(inputPath, baseName, size)
        )
      );
    }
    
    console.log('All images optimized successfully!');
  } catch (error) {
    console.error('Error optimizing images:', error);
    process.exit(1);
  }
}

processImages();