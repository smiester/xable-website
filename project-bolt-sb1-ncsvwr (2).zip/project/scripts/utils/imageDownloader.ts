import fetch from 'node-fetch';
import fs from 'fs/promises';

export async function ensureDir(dir: string): Promise<void> {
  try {
    await fs.mkdir(dir, { recursive: true });
  } catch (error: any) {
    if (error.code !== 'EEXIST') throw error;
  }
}

export async function downloadImage(url: string): Promise<Buffer> {
  const response = await fetch(`${url}?auto=format&fit=crop&q=80`);
  if (!response.ok) {
    throw new Error(`Failed to fetch image: ${response.statusText}`);
  }
  return Buffer.from(await response.arrayBuffer());
}