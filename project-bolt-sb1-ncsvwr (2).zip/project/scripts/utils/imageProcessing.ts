import sharp from 'sharp';
import path from 'path';

export const IMAGE_SIZES = {
  thumbnail: 200,
  small: 400,
  medium: 800,
  large: 1200
};

export async function processImage(buffer: Buffer, outputPath: string, size: number): Promise<void> {
  await sharp(buffer)
    .resize(size, null, { 
      withoutEnlargement: true,
      fit: 'cover'
    })
    .webp({ quality: 80 })
    .toFile(outputPath);
}

export function getImagePath(category: string, name: string, size: string): string {
  return path.join('public/images', `${category}-${name}-${size}.webp`);
}