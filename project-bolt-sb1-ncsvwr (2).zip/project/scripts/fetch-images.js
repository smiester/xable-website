import fetch from 'node-fetch';
import fs from 'fs/promises';
import path from 'path';
import sharp from 'sharp';

const IMAGES = {
  approach: {
    personCentered: "https://images.unsplash.com/photo-1603354350317-6f7aaa5911c5",
    evidenceBased: "https://images.unsplash.com/photo-1516627145497-ae6968895b74",
    collaborative: "https://images.unsplash.com/photo/tuTMECjFBdk"
  }
};

const OUTPUT_DIR = 'public/images';
const SIZES = {
  thumbnail: 200,
  small: 400,
  medium: 800,
  large: 1200
};

async function ensureDir(dir) {
  try {
    await fs.mkdir(dir, { recursive: true });
  } catch (error) {
    if (error.code !== 'EEXIST') throw error;
  }
}

async function downloadImage(url) {
  const response = await fetch(`${url}?auto=format&fit=crop&q=80`);
  if (!response.ok) {
    throw new Error(`Failed to fetch image: ${response.statusText}`);
  }
  return Buffer.from(await response.arrayBuffer());
}

async function processImage(buffer, name, size) {
  const outputPath = path.join(OUTPUT_DIR, `${name}-${size}.webp`);
  return sharp(buffer)
    .resize(SIZES[size], null, { 
      withoutEnlargement: true,
      fit: 'cover'
    })
    .webp({ quality: 80 })
    .toFile(outputPath);
}

async function processImages() {
  try {
    await ensureDir(OUTPUT_DIR);
    
    for (const [category, images] of Object.entries(IMAGES)) {
      for (const [name, url] of Object.entries(images)) {
        console.log(`Processing ${category}/${name} image...`);
        const buffer = await downloadImage(url);
        
        for (const sizeName of Object.keys(SIZES)) {
          await processImage(buffer, `${category}-${name}`, sizeName);
        }
      }
    }

    console.log('All images processed successfully!');
  } catch (error) {
    console.error('Error processing images:', error);
    process.exit(1);
  }
}

processImages();