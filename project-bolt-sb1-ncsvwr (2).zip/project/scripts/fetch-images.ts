import { APPROACH_IMAGE_URLS } from '../src/constants/imageUrls.js';
import { IMAGE_SIZES, processImage, getImagePath } from './utils/imageProcessing.js';
import { ensureDir, downloadImage } from './utils/imageDownloader.js';

const OUTPUT_DIR = 'public/images';

async function processImages() {
  try {
    await ensureDir(OUTPUT_DIR);
    
    for (const [name, url] of Object.entries(APPROACH_IMAGE_URLS)) {
      console.log(`Processing approach/${name} image...`);
      const buffer = await downloadImage(url);
      
      for (const [sizeName, size] of Object.entries(IMAGE_SIZES)) {
        const outputPath = getImagePath('approach', name, sizeName);
        await processImage(buffer, outputPath, size);
      }
    }

    console.log('All images processed successfully!');
  } catch (error) {
    console.error('Error processing images:', error);
    process.exit(1);
  }
}

processImages();