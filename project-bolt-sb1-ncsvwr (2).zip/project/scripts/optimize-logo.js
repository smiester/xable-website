import sharp from 'sharp';
import fs from 'fs/promises';
import path from 'path';

const IMAGE_SIZES = {
  thumbnail: 100,
  small: 200,
  medium: 300,
  large: 400
};

const OUTPUT_DIR = 'public/images';
const QUALITY = 85;

async function optimizeLogo() {
  try {
    // Ensure output directory exists
    await fs.mkdir(OUTPUT_DIR, { recursive: true });
    
    // Create a temporary working copy of the input file
    const inputPath = 'public/images/logo-large.webp';
    const tempPath = 'public/images/logo-temp.webp';
    
    await fs.copyFile(inputPath, tempPath);
    
    // Process each size
    for (const [size, width] of Object.entries(IMAGE_SIZES)) {
      const outputPath = path.join(OUTPUT_DIR, `logo-${size}.webp`);
      
      await sharp(tempPath)
        .resize(width, width, {
          fit: 'contain',
          background: { r: 255, g: 255, b: 255, alpha: 0 }
        })
        .webp({ quality: QUALITY })
        .toFile(outputPath);
        
      console.log(`Generated ${size} logo: ${outputPath}`);
    }
    
    // Clean up temporary file
    await fs.unlink(tempPath);
    
    console.log('Logo optimization complete!');
  } catch (error) {
    console.error('Error optimizing logo:', error);
    process.exit(1);
  }
}

optimizeLogo();