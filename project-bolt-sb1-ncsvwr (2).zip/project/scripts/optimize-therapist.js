import fs from 'fs/promises';
import path from 'path';
import sharp from 'sharp';

const OUTPUT_DIR = 'public/images';
const SIZES = {
  thumbnail: 200,
  small: 400,
  medium: 800,
  large: 1200
};

async function ensureDir(dir) {
  try {
    await fs.mkdir(dir, { recursive: true });
  } catch (error) {
    if (error.code !== 'EEXIST') throw error;
  }
}

async function optimizeTherapistImages() {
  try {
    await ensureDir(OUTPUT_DIR);
    
    // Read the original large image first
    const inputPath = path.join(OUTPUT_DIR, 'team-therapist-large.webp');
    const inputBuffer = await fs.readFile(inputPath);
    
    // Process each size except large (since we already have it)
    for (const [sizeName, width] of Object.entries(SIZES)) {
      if (sizeName === 'large') continue; // Skip large size since we already have it
      
      const outputPath = path.join(OUTPUT_DIR, `team-therapist-${sizeName}.webp`);
      
      await sharp(inputBuffer)
        .resize(width, null, {
          withoutEnlargement: true,
          fit: 'cover'
        })
        .webp({ quality: 80 })
        .toFile(outputPath);
        
      console.log(`Created ${sizeName} version: ${outputPath}`);
    }
    
    console.log('Therapist images optimized successfully!');
  } catch (error) {
    console.error('Error optimizing therapist images:', error);
    process.exit(1);
  }
}

optimizeTherapistImages();