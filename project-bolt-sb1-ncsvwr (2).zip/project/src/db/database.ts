import Dexie, { Table } from 'dexie';
import { Post } from '../types/blog';

interface User {
  id: string;
  username: string;
  passwordHash: string;
  role: 'admin';
  createdAt: Date;
}

interface Session {
  id: string;
  userId: string;
  createdAt: Date;
  expiresAt: Date;
}

export class BlogDatabase extends Dexie {
  posts!: Table<Post>;
  users!: Table<User>;
  sessions!: Table<Session>;

  constructor() {
    super('BlogDatabase');
    
    this.version(3).stores({
      posts: '++id, slug, isDraft',
      users: 'id, username, role',
      sessions: 'id, userId, expiresAt'
    });

    this.posts.hook('creating', (primKey, obj) => {
      if (!(obj.publishedAt instanceof Date)) {
        obj.publishedAt = new Date(obj.publishedAt);
      }
      if (!(obj.updatedAt instanceof Date)) {
        obj.updatedAt = new Date(obj.updatedAt);
      }
      return obj;
    });

    this.posts.hook('reading', obj => {
      if (!(obj.publishedAt instanceof Date)) {
        obj.publishedAt = new Date(obj.publishedAt);
      }
      if (!(obj.updatedAt instanceof Date)) {
        obj.updatedAt = new Date(obj.updatedAt);
      }
      return obj;
    });

    this.on('ready', async () => {
      const userCount = await this.users.count();
      if (userCount === 0) {
        const { authService } = await import('../services/authService');
        const passwordHash = await authService.hashPassword('Meg@1012');
        
        await this.users.add({
          id: '1',
          username: 'Arsalan',
          passwordHash,
          role: 'admin',
          createdAt: new Date()
        });
      }
    });
  }

  async cleanupSessions(): Promise<void> {
    const now = new Date();
    await this.sessions
      .where('expiresAt')
      .below(now)
      .delete();
  }
}

export const db = new BlogDatabase();

setInterval(() => {
  db.cleanupSessions();
}, 15 * 60 * 1000);