export const IMAGE_SIZES = {
  thumbnail: 200,
  small: 400,
  medium: 800,
  large: 1200
};

export const LOGO_SIZES = {
  thumbnail: 100,
  small: 200,
  medium: 300,
  large: 400
};

export function getSrcSet(paths) {
  return Object.entries(paths)
    .map(([size, path]) => `${path} ${IMAGE_SIZES[size]}w`)
    .join(', ');
}

export function getLogoSrcSet(paths) {
  return Object.entries(paths)
    .map(([size, path]) => `${path} ${LOGO_SIZES[size]}w`)
    .join(', ');
}

export function getImageDimensions(size, isLogo = false) {
  const sizes = isLogo ? LOGO_SIZES : IMAGE_SIZES;
  const width = sizes[size];
  const height = isLogo ? width : Math.round(width * (3 / 4));
  return { width, height };
}