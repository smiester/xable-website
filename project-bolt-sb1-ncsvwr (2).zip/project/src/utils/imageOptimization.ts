import sharp from 'sharp';

export const IMAGE_SIZES = {
  thumbnail: 200,
  small: 400,
  medium: 800,
  large: 1200
} as const;

export type ImageSize = keyof typeof IMAGE_SIZES;

export interface OptimizedImagePaths {
  thumbnail: string;
  small: string;
  medium: string;
  large: string;
}

export async function optimizeImage(
  input: Buffer,
  outputPath: string,
  size: number,
  quality = 80
): Promise<string> {
  await sharp(input)
    .resize(size, null, {
      withoutEnlargement: true,
      fit: 'cover'
    })
    .webp({ quality })
    .toFile(outputPath);
    
  return outputPath;
}

export function getSrcSet(paths: OptimizedImagePaths): string {
  return Object.entries(paths)
    .map(([size, path]) => `${path} ${IMAGE_SIZES[size as ImageSize]}w`)
    .join(', ');
}

export function getImageDimensions(size: ImageSize): { width: number; height: number } {
  const width = IMAGE_SIZES[size];
  const height = Math.round(width * (3 / 4)); // 4:3 aspect ratio
  return { width, height };
}