export const generateStructuredData = () => {
  const structuredData = {
    "@context": "https://schema.org",
    "@type": "MedicalBusiness",
    "name": "Xable Therapy Services",
    "description": "Specialized therapy services for individuals with special needs in Western GTA",
    "address": {
      "@type": "PostalAddress",
      "addressRegion": "Ontario",
      "addressCountry": "CA"
    },
    "geo": {
      "@type": "GeoCoordinates",
      "latitude": "43.5890",
      "longitude": "-79.6441"
    },
    "url": "https://xable.ca",
    "telephone": "",
    "email": "info@xable.ca",
    "medicalSpecialty": [
      "Behavioral Therapy",
      "Developmental Psychology",
      "Special Needs Support",
      "Autism Therapy",
      "ADHD Support"
    ],
    "availableService": [
      {
        "@type": "MedicalTherapy",
        "name": "Individual Therapy",
        "description": "Personalized sessions focused on individual growth and development"
      },
      {
        "@type": "MedicalTherapy",
        "name": "Group Sessions",
        "description": "Safe spaces for social interaction and peer support"
      },
      {
        "@type": "MedicalTherapy",
        "name": "Cognitive Development",
        "description": "Programs to enhance learning and cognitive abilities"
      }
    ],
    "sameAs": [
      "https://www.linkedin.com/company/xable-therapy",
      "https://www.facebook.com/xabletherapy"
    ],
    "openingHoursSpecification": {
      "@type": "OpeningHoursSpecification",
      "dayOfWeek": [
        "Monday",
        "Tuesday",
        "Wednesday",
        "Thursday",
        "Friday"
      ],
      "opens": "09:00",
      "closes": "17:00"
    },
    "priceRange": "$$",
    "hasOfferCatalog": {
      "@type": "OfferCatalog",
      "name": "Therapy Services",
      "itemListElement": [
        {
          "@type": "Offer",
          "itemOffered": {
            "@type": "Service",
            "name": "Individual Therapy Session",
            "description": "One-on-one therapy sessions tailored to individual needs"
          }
        },
        {
          "@type": "Offer",
          "itemOffered": {
            "@type": "Service",
            "name": "Group Therapy Session",
            "description": "Therapeutic group sessions for social skills development"
          }
        }
      ]
    }
  };

  return JSON.stringify(structuredData);
};

export const generateSitemap = () => {
  const baseUrl = 'https://xable.ca';
  const pages = [
    '',
    '#services',
    '#approach',
    '#team',
    '#blog',
    '#contact'
  ];

  const sitemap = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  ${pages.map(page => `
    <url>
      <loc>${baseUrl}${page}</loc>
      <changefreq>weekly</changefreq>
      <priority>${page === '' ? '1.0' : '0.8'}</priority>
    </url>
  `).join('')}
</urlset>`;

  return sitemap;
};