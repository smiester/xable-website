import { SignJWT, jwtVerify } from 'jose';
import { v4 as uuidv4 } from 'uuid';
import bcrypt from 'bcryptjs';
import { db } from '../db/database';

const JWT_SECRET = new TextEncoder().encode('your-secure-secret-key');
const SALT_ROUNDS = 12;
const TOKEN_EXPIRY = '2h';

export interface User {
  id: string;
  username: string;
  role: 'admin';
  sessionId?: string;
}

interface Session {
  id: string;
  userId: string;
  createdAt: Date;
  expiresAt: Date;
}

class AuthError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'AuthError';
  }
}

export const authService = {
  async hashPassword(password: string): Promise<string> {
    return bcrypt.hash(password, SALT_ROUNDS);
  },

  async verifyPassword(password: string, hash: string): Promise<boolean> {
    return bcrypt.compare(password, hash);
  },

  async createSession(userId: string): Promise<Session> {
    const session: Session = {
      id: uuidv4(),
      userId,
      createdAt: new Date(),
      expiresAt: new Date(Date.now() + 2 * 60 * 60 * 1000), // 2 hours
    };

    await db.sessions.add(session);
    return session;
  },

  async generateToken(user: User, sessionId: string): Promise<string> {
    const token = await new SignJWT({ 
      user: { ...user, sessionId }
    })
      .setProtectedHeader({ alg: 'HS256' })
      .setExpirationTime(TOKEN_EXPIRY)
      .setJti(uuidv4())
      .setIssuedAt()
      .sign(JWT_SECRET);

    return token;
  },

  async login(username: string, password: string): Promise<string> {
    try {
      const user = await db.users.where('username').equals(username).first();
      
      if (!user) {
        throw new AuthError('Invalid credentials');
      }

      const isValid = await this.verifyPassword(password, user.passwordHash);
      if (!isValid) {
        throw new AuthError('Invalid credentials');
      }

      const session = await this.createSession(user.id);
      const token = await this.generateToken(
        { id: user.id, username: user.username, role: user.role },
        session.id
      );

      return token;
    } catch (error) {
      console.error('Login error:', error);
      throw error;
    }
  },

  async verifyToken(token: string): Promise<User | null> {
    try {
      const { payload } = await jwtVerify(token, JWT_SECRET);
      const user = payload.user as User;

      const session = await db.sessions
        .where('id')
        .equals(user.sessionId!)
        .first();

      if (!session || new Date() > new Date(session.expiresAt)) {
        return null;
      }

      return user;
    } catch (error) {
      console.error('Token verification error:', error);
      return null;
    }
  },

  async logout(sessionId: string): Promise<void> {
    await db.sessions.where('id').equals(sessionId).delete();
    localStorage.removeItem('auth_token');
  },

  getToken(): string | null {
    return localStorage.getItem('auth_token');
  },

  generateCsrfToken(): string {
    const token = uuidv4();
    localStorage.setItem('csrf_token', token);
    return token;
  },

  validateCsrfToken(token: string): boolean {
    const storedToken = localStorage.getItem('csrf_token');
    return token === storedToken;
  }
};