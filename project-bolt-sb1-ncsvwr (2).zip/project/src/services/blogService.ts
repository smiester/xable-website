import { db } from '../db/database';
import { Post, PostFormData } from '../types/blog';
import slugify from 'slugify';

export const blogService = {
  async getAllPosts(): Promise<Post[]> {
    try {
      return await db.posts.orderBy('publishedAt').reverse().toArray();
    } catch (error) {
      console.error('Error fetching posts:', error);
      return [];
    }
  },

  async getPublishedPosts(): Promise<Post[]> {
    try {
      return await db.posts
        .where('isDraft')
        .equals(0)
        .reverse()
        .sortBy('publishedAt');
    } catch (error) {
      console.error('Error fetching published posts:', error);
      return [];
    }
  },

  async getPostBySlug(slug: string): Promise<Post | undefined> {
    try {
      return await db.posts
        .where('slug')
        .equals(slug)
        .first();
    } catch (error) {
      console.error('Error fetching post by slug:', error);
      return undefined;
    }
  },

  async createPost(postData: PostFormData): Promise<number> {
    const now = new Date();
    const post: Omit<Post, 'id'> = {
      ...postData,
      slug: slugify(postData.title.toLowerCase()),
      author: 'Admin', // Replace with actual user
      publishedAt: now,
      updatedAt: now,
    };
    return await db.posts.add(post);
  },

  async updatePost(id: number, postData: PostFormData): Promise<void> {
    const post = {
      ...postData,
      slug: slugify(postData.title.toLowerCase()),
      updatedAt: new Date(),
    };
    await db.posts.update(id, post);
  },

  async deletePost(id: number): Promise<void> {
    await db.posts.delete(id);
  },

  async getPostById(id: number): Promise<Post | undefined> {
    return await db.posts.get(id);
  }
};