export interface Post {
  id?: number;
  title: string;
  slug: string;
  content: string;
  excerpt: string;
  author: string;
  publishedAt: Date;
  updatedAt: Date;
  isDraft: 0 | 1;
  featuredImage?: string;
  tags: string[];
}

export interface PostFormData {
  title: string;
  content: string;
  excerpt: string;
  isDraft: 0 | 1;
  featuredImage?: string;
  tags: string[];
}