import React from 'react';
import { IMAGE_SIZES, getSrcSet, getImageDimensions } from '../../utils/imageOptimization.js';

interface OptimizedImagePaths {
  thumbnail: string;
  small: string;
  medium: string;
  large: string;
}

interface ResponsiveImageProps extends Omit<React.ImgHTMLAttributes<HTMLImageElement>, 'src'> {
  sources: OptimizedImagePaths;
  alt: string;
  className?: string;
  priority?: boolean;
}

export function ResponsiveImage({ 
  sources, 
  alt, 
  className = '', 
  priority = false,
  ...props 
}: ResponsiveImageProps) {
  const { width, height } = getImageDimensions('large');
  
  return (
    <picture>
      <source
        type="image/webp"
        srcSet={getSrcSet(sources)}
        sizes="(min-width: 1280px) 1200px, (min-width: 768px) 800px, (min-width: 640px) 400px, 200px"
      />
      <img
        src={sources.medium}
        alt={alt}
        width={width}
        height={height}
        className={`w-full h-auto ${className}`}
        loading={priority ? 'eager' : 'lazy'}
        decoding={priority ? 'sync' : 'async'}
        {...props}
      />
    </picture>
  );
}