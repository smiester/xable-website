import React from 'react';

interface OptimizedImageProps extends React.ImgHTMLAttributes<HTMLImageElement> {
  src: {
    thumbnail: string;
    small: string;
    medium: string;
    large: string;
  };
}

export function OptimizedImage({ src, alt, ...props }: OptimizedImageProps) {
  return (
    <picture>
      <source
        media="(min-width: 1024px)"
        srcSet={src.large}
        type="image/webp"
      />
      <source
        media="(min-width: 768px)"
        srcSet={src.medium}
        type="image/webp"
      />
      <source
        media="(min-width: 640px)"
        srcSet={src.small}
        type="image/webp"
      />
      <img
        src={src.thumbnail}
        alt={alt}
        loading="lazy"
        {...props}
      />
    </picture>
  );
}