import React from 'react';
import { motion, HTMLMotionProps } from 'framer-motion';
import { useInView } from 'react-intersection-observer';

interface AnimatedSectionProps extends HTMLMotionProps<'div'> {
  children: React.ReactNode;
  delay?: number;
  threshold?: number;
}

export function AnimatedSection({ 
  children, 
  delay = 0, 
  threshold = 0.1,
  ...props 
}: AnimatedSectionProps) {
  const [ref, inView] = useInView({
    threshold,
    triggerOnce: true
  });

  return (
    <motion.div
      ref={ref}
      initial="hidden"
      animate={inView ? "visible" : "hidden"}
      transition={{ delay }}
      {...props}
    >
      {children}
    </motion.div>
  );
}