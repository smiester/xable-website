import React from 'react';
import { Type, Contrast, Eye } from 'lucide-react';
import { useAccessibility } from './AccessibilityContext';
import { SettingSlider } from './controls/SettingSlider';
import { SettingSelect } from './controls/SettingSelect';
import { SettingToggle } from './controls/SettingToggle';

export function AccessibilitySettings() {
  const { settings, updateSetting } = useAccessibility();

  return (
    <div className="space-y-6">
      <section aria-labelledby="text-settings">
        <h3 id="text-settings" className="text-sm font-medium text-gray-700 mb-4">
          <Type className="h-4 w-4 inline mr-2" />
          Text Settings
        </h3>
        
        <div className="space-y-4">
          <SettingSlider
            label="Text Size"
            value={settings.fontSize}
            onChange={(value) => updateSetting('fontSize', value)}
            min={80}
            max={200}
            step={10}
            ariaValueText={(value) => `${value}% text size`}
          />

          <SettingSlider
            label="Letter Spacing"
            value={settings.letterSpacing}
            onChange={(value) => updateSetting('letterSpacing', value)}
            min={0}
            max={5}
            step={0.5}
            ariaValueText={(value) => `${value}px letter spacing`}
          />

          <SettingSlider
            label="Line Height"
            value={settings.lineHeight}
            onChange={(value) => updateSetting('lineHeight', value)}
            min={1}
            max={2}
            step={0.1}
            ariaValueText={(value) => `${value}x line height`}
          />

          <SettingSelect
            label="Text Alignment"
            value={settings.textAlign}
            onChange={(value) => updateSetting('textAlign', value)}
            options={[
              { value: 'left', label: 'Left' },
              { value: 'center', label: 'Center' },
              { value: 'right', label: 'Right' },
              { value: 'justify', label: 'Justify' }
            ]}
          />

          <SettingSelect
            label="Font Family"
            value={settings.fontFamily}
            onChange={(value) => updateSetting('fontFamily', value)}
            options={[
              { value: 'default', label: 'Default' },
              { value: 'dyslexic', label: 'Dyslexic Friendly' },
              { value: 'monospace', label: 'Monospace' }
            ]}
          />
        </div>
      </section>

      <section aria-labelledby="visual-settings">
        <h3 id="visual-settings" className="text-sm font-medium text-gray-700 mb-4">
          <Eye className="h-4 w-4 inline mr-2" />
          Visual Settings
        </h3>
        
        <div className="space-y-4">
          <SettingSelect
            label="Contrast"
            value={settings.contrast}
            onChange={(value) => updateSetting('contrast', value)}
            options={[
              { value: 'normal', label: 'Normal' },
              { value: 'high', label: 'High Contrast' },
              { value: 'dark', label: 'Dark Mode' }
            ]}
          />

          <SettingToggle
            label="Reduce Motion"
            checked={settings.reducedMotion}
            onChange={(value) => updateSetting('reducedMotion', value)}
          />

          <SettingToggle
            label="Focus Indicator"
            checked={settings.focusIndicator}
            onChange={(value) => updateSetting('focusIndicator', value)}
          />
        </div>
      </section>
    </div>
  );
}