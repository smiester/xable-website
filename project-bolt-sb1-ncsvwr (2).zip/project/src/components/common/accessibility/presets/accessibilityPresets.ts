export const accessibilityPresets = {
  blind: {
    name: 'Screen Reader Optimized',
    description: 'Optimized for screen readers with enhanced keyboard navigation',
    settings: {
      fontSize: 120,
      contrast: 'high',
      reducedMotion: true,
      letterSpacing: 1,
      lineHeight: 1.8,
      focusIndicator: true,
      textAlign: 'left',
      fontFamily: 'default'
    }
  },
  colorBlind: {
    name: 'Color Blind Friendly',
    description: 'Enhanced contrast and color-independent visual cues',
    settings: {
      fontSize: 100,
      contrast: 'high',
      reducedMotion: false,
      letterSpacing: 0.5,
      lineHeight: 1.5,
      focusIndicator: true,
      textAlign: 'left',
      fontFamily: 'default'
    }
  },
  visuallyImpaired: {
    name: 'Low Vision',
    description: 'Larger text and enhanced contrast for better visibility',
    settings: {
      fontSize: 150,
      contrast: 'high',
      reducedMotion: true,
      letterSpacing: 1.5,
      lineHeight: 1.8,
      focusIndicator: true,
      textAlign: 'left',
      fontFamily: 'default'
    }
  },
  adhd: {
    name: 'ADHD Friendly',
    description: 'Focused reading experience with reduced distractions',
    settings: {
      fontSize: 110,
      contrast: 'normal',
      reducedMotion: true,
      letterSpacing: 0.8,
      lineHeight: 1.8,
      focusIndicator: true,
      textAlign: 'left',
      fontFamily: 'monospace'
    }
  }
};