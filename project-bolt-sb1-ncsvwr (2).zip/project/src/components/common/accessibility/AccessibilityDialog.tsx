import React from 'react';
import { Dialog } from '@headlessui/react';
import { X, Settings } from 'lucide-react';
import { AccessibilitySettings } from './AccessibilitySettings';
import { AccessibilityPresets } from './AccessibilityPresets';
import { useAccessibility } from './AccessibilityContext';

interface AccessibilityDialogProps {
  isOpen: boolean;
  onClose: () => void;
}

export function AccessibilityDialog({ isOpen, onClose }: AccessibilityDialogProps) {
  const { resetSettings } = useAccessibility();
  const [showAdvanced, setShowAdvanced] = React.useState(false);

  return (
    <Dialog
      open={isOpen}
      onClose={onClose}
      className="fixed inset-0 z-50 overflow-y-auto"
      aria-labelledby="accessibility-dialog-title"
    >
      <div className="flex min-h-screen items-center justify-center p-4">
        <Dialog.Overlay className="fixed inset-0 bg-black/30" />

        <div className="relative bg-white rounded-lg shadow-xl max-w-md w-full p-6">
          <div className="flex justify-between items-center mb-4">
            <Dialog.Title
              id="accessibility-dialog-title"
              className="text-lg font-semibold"
            >
              Accessibility Settings
            </Dialog.Title>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-500"
              aria-label="Close accessibility settings"
            >
              <X className="h-6 w-6" />
            </button>
          </div>

          <div className="space-y-6">
            <AccessibilityPresets />
            
            <div className="border-t pt-4">
              <button
                onClick={() => setShowAdvanced(!showAdvanced)}
                className="flex items-center text-sm text-purple-600 hover:text-purple-700"
              >
                <Settings className="h-4 w-4 mr-2" />
                {showAdvanced ? 'Hide Advanced Settings' : 'Show Advanced Settings'}
              </button>
            </div>

            {showAdvanced && (
              <div className="border-t pt-4">
                <AccessibilitySettings />
              </div>
            )}
            
            <div className="flex justify-between pt-4 border-t">
              <button
                onClick={resetSettings}
                className="text-sm text-gray-500 hover:text-gray-700"
              >
                Reset to Defaults
              </button>
              <button
                onClick={onClose}
                className="bg-purple-600 text-white px-4 py-2 rounded-md hover:bg-purple-700"
              >
                Save Changes
              </button>
            </div>
          </div>
        </div>
      </div>
    </Dialog>
  );
}