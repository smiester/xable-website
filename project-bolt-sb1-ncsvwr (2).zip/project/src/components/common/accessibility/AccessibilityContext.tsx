import React, { createContext, useContext, useState, useEffect } from 'react';

interface AccessibilitySettings {
  fontSize: number;
  contrast: 'normal' | 'high' | 'dark';
  reducedMotion: boolean;
  letterSpacing: number;
  lineHeight: number;
  focusIndicator: boolean;
  textAlign: 'left' | 'center' | 'right' | 'justify';
  fontFamily: 'default' | 'dyslexic' | 'monospace';
}

interface AccessibilityContextType {
  settings: AccessibilitySettings;
  updateSetting: <K extends keyof AccessibilitySettings>(
    key: K,
    value: AccessibilitySettings[K]
  ) => void;
  resetSettings: () => void;
}

const defaultSettings: AccessibilitySettings = {
  fontSize: 100,
  contrast: 'normal',
  reducedMotion: false,
  letterSpacing: 0,
  lineHeight: 1.5,
  focusIndicator: true,
  textAlign: 'left',
  fontFamily: 'default'
};

const AccessibilityContext = createContext<AccessibilityContextType | undefined>(undefined);

export function AccessibilityProvider({ children }: { children: React.ReactNode }) {
  const [settings, setSettings] = useState<AccessibilitySettings>(() => {
    const saved = localStorage.getItem('accessibility_settings');
    return saved ? JSON.parse(saved) : defaultSettings;
  });

  useEffect(() => {
    localStorage.setItem('accessibility_settings', JSON.stringify(settings));
    applySettings(settings);
  }, [settings]);

  const updateSetting = <K extends keyof AccessibilitySettings>(
    key: K,
    value: AccessibilitySettings[K]
  ) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  const resetSettings = () => {
    setSettings(defaultSettings);
  };

  return (
    <AccessibilityContext.Provider value={{ settings, updateSetting, resetSettings }}>
      {children}
    </AccessibilityContext.Provider>
  );
}

export function useAccessibility() {
  const context = useContext(AccessibilityContext);
  if (!context) {
    throw new Error('useAccessibility must be used within an AccessibilityProvider');
  }
  return context;
}

function applySettings(settings: AccessibilitySettings) {
  document.documentElement.style.fontSize = `${settings.fontSize}%`;
  document.documentElement.style.letterSpacing = `${settings.letterSpacing}px`;
  document.documentElement.style.lineHeight = settings.lineHeight.toString();
  
  // Apply contrast settings
  document.body.classList.remove('high-contrast', 'dark-mode');
  if (settings.contrast === 'high') {
    document.body.classList.add('high-contrast');
  } else if (settings.contrast === 'dark') {
    document.body.classList.add('dark-mode');
  }

  // Apply reduced motion
  if (settings.reducedMotion) {
    document.body.classList.add('reduce-motion');
  } else {
    document.body.classList.remove('reduce-motion');
  }

  // Apply focus indicator
  if (settings.focusIndicator) {
    document.body.classList.remove('hide-focus-rings');
  } else {
    document.body.classList.add('hide-focus-rings');
  }

  // Apply text alignment
  document.body.style.textAlign = settings.textAlign;

  // Apply font family
  document.body.classList.remove('font-dyslexic', 'font-monospace');
  if (settings.fontFamily === 'dyslexic') {
    document.body.classList.add('font-dyslexic');
  } else if (settings.fontFamily === 'monospace') {
    document.body.classList.add('font-monospace');
  }
}