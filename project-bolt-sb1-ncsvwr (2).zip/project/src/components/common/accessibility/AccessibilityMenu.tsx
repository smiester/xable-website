import React, { useState } from 'react';
import { Settings } from 'lucide-react';
import { AccessibilityDialog } from './AccessibilityDialog';
import { useAccessibility } from './AccessibilityContext';

export function AccessibilityMenu() {
  const [isOpen, setIsOpen] = useState(false);
  const { settings } = useAccessibility();

  return (
    <div className="fixed bottom-4 right-4 z-50">
      <button
        onClick={() => setIsOpen(true)}
        className="bg-purple-600 text-white p-3 rounded-full shadow-lg hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500"
        aria-label="Open accessibility settings"
        aria-expanded={isOpen}
        aria-haspopup="dialog"
      >
        <Settings className="h-6 w-6" aria-hidden="true" />
      </button>

      <AccessibilityDialog
        isOpen={isOpen}
        onClose={() => setIsOpen(false)}
        settings={settings}
      />
    </div>
  );
}