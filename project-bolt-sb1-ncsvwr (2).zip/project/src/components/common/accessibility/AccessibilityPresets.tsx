import React from 'react';
import { Eye, Brain, Contrast, Monitor } from 'lucide-react';
import { useAccessibility } from './AccessibilityContext';
import { accessibilityPresets } from './presets/accessibilityPresets';

const presetIcons = {
  blind: Monitor,
  colorBlind: Contrast,
  visuallyImpaired: Eye,
  adhd: Brain
};

export function AccessibilityPresets() {
  const { updateSetting } = useAccessibility();

  const applyPreset = (presetKey: keyof typeof accessibilityPresets) => {
    const preset = accessibilityPresets[presetKey];
    Object.entries(preset.settings).forEach(([key, value]) => {
      updateSetting(key as any, value);
    });
  };

  return (
    <div className="space-y-4">
      <h3 className="text-sm font-medium text-gray-700">Quick Settings</h3>
      <div className="grid grid-cols-1 gap-4">
        {(Object.entries(accessibilityPresets) as [keyof typeof accessibilityPresets, any][]).map(([key, preset]) => {
          const Icon = presetIcons[key];
          return (
            <button
              key={key}
              onClick={() => applyPreset(key)}
              className="flex items-start gap-3 p-3 text-left border rounded-lg hover:border-purple-500 hover:bg-purple-50 transition-colors"
            >
              <div className="flex-shrink-0">
                <Icon className="h-5 w-5 text-purple-600" />
              </div>
              <div>
                <div className="font-medium text-gray-900">{preset.name}</div>
                <div className="text-sm text-gray-500">{preset.description}</div>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}