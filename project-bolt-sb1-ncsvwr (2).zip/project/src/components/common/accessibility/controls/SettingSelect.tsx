import React from 'react';

interface Option {
  value: string;
  label: string;
}

interface SettingSelectProps {
  label: string;
  value: string;
  onChange: (value: string) => void;
  options: Option[];
}

export function SettingSelect({
  label,
  value,
  onChange,
  options
}: SettingSelectProps) {
  const id = `setting-${label.toLowerCase().replace(/\s+/g, '-')}`;

  return (
    <div>
      <label htmlFor={id} className="block text-sm font-medium text-gray-700 mb-1">
        {label}
      </label>
      <select
        id={id}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500"
      >
        {options.map((option) => (
          <option key={option.value} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
    </div>
  );
}