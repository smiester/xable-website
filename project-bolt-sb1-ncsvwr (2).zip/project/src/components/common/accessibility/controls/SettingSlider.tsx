import React from 'react';

interface SettingSliderProps {
  label: string;
  value: number;
  onChange: (value: number) => void;
  min: number;
  max: number;
  step: number;
  ariaValueText: (value: number) => string;
}

export function SettingSlider({
  label,
  value,
  onChange,
  min,
  max,
  step,
  ariaValueText
}: SettingSliderProps) {
  const id = `setting-${label.toLowerCase().replace(/\s+/g, '-')}`;

  return (
    <div>
      <label htmlFor={id} className="block text-sm font-medium text-gray-700 mb-1">
        {label}
      </label>
      <input
        type="range"
        id={id}
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="w-full"
        aria-valuemin={min}
        aria-valuemax={max}
        aria-valuenow={value}
        aria-valuetext={ariaValueText(value)}
      />
      <div className="text-sm text-gray-500 mt-1">{ariaValueText(value)}</div>
    </div>
  );
}