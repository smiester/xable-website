import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import slugify from 'slugify';
import { db } from '../../db/database';
import { PostFormData } from '../../types/blog';
import { Editor } from './Editor';

interface PostFormProps {
  initialData?: PostFormData;
  postId?: number;
}

export function PostForm({ initialData, postId }: PostFormProps) {
  const navigate = useNavigate();
  const [formData, setFormData] = useState<PostFormData>(initialData || {
    title: '',
    content: '',
    excerpt: '',
    isDraft: true,
    tags: [],
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const slug = slugify(formData.title.toLowerCase());
    const now = new Date();
    
    const postData = {
      ...formData,
      slug,
      author: 'Admin', // Replace with actual user
      publishedAt: now,
      updatedAt: now,
    };

    if (postId) {
      await db.posts.update(postId, postData);
    } else {
      await db.posts.add(postData);
    }

    navigate('/admin/posts');
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div>
        <label htmlFor="title" className="block text-sm font-medium text-gray-700">
          Title
        </label>
        <input
          type="text"
          id="title"
          value={formData.title}
          onChange={(e) => setFormData({ ...formData, title: e.target.value })}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500"
          required
        />
      </div>

      <div>
        <label htmlFor="excerpt" className="block text-sm font-medium text-gray-700">
          Excerpt
        </label>
        <textarea
          id="excerpt"
          value={formData.excerpt}
          onChange={(e) => setFormData({ ...formData, excerpt: e.target.value })}
          rows={3}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500"
          required
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Content
        </label>
        <Editor
          content={formData.content}
          onChange={(content) => setFormData({ ...formData, content })}
        />
      </div>

      <div>
        <label htmlFor="tags" className="block text-sm font-medium text-gray-700">
          Tags (comma-separated)
        </label>
        <input
          type="text"
          id="tags"
          value={formData.tags.join(', ')}
          onChange={(e) => setFormData({
            ...formData,
            tags: e.target.value.split(',').map(tag => tag.trim()).filter(Boolean)
          })}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500"
        />
      </div>

      <div className="flex items-center">
        <input
          type="checkbox"
          id="isDraft"
          checked={formData.isDraft}
          onChange={(e) => setFormData({ ...formData, isDraft: e.target.checked })}
          className="h-4 w-4 rounded border-gray-300 text-purple-600 focus:ring-purple-500"
        />
        <label htmlFor="isDraft" className="ml-2 block text-sm text-gray-900">
          Save as draft
        </label>
      </div>

      <div className="flex justify-end gap-4">
        <button
          type="button"
          onClick={() => navigate('/admin/posts')}
          className="px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
        >
          Cancel
        </button>
        <button
          type="submit"
          className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-purple-600 hover:bg-purple-700"
        >
          {postId ? 'Update Post' : 'Create Post'}
        </button>
      </div>
    </form>
  );
}