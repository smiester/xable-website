import React from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import { Header } from './Header';
import { Hero } from '../home/Hero';
import { Services } from '../home/Services';
import { Approach } from '../home/Approach';
import { Team } from '../home/Team';
import { Contact } from '../home/Contact';
import { BlogSection } from '../home/BlogSection';
import { SkipLink } from '../common/SkipLink';
import { AccessibilityMenu } from '../common/AccessibilityMenu';

export function PublicLayout() {
  const location = useLocation();
  const isHomePage = location.pathname === '/';

  return (
    <div className="min-h-screen bg-white">
      <SkipLink />
      <Header />
      <main id="main-content" className="pt-16" tabIndex={-1}>
        {isHomePage ? (
          <>
            <Hero />
            <Services />
            <Approach />
            <Team />
            <BlogSection />
            <Contact />
          </>
        ) : (
          <div className="pt-8">
            <Outlet />
          </div>
        )}
      </main>
      <footer className="bg-gray-50 py-12" role="contentinfo">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <p className="text-center text-gray-500">
            © {new Date().getFullYear()} Xable. All rights reserved.
          </p>
        </div>
      </footer>
      <AccessibilityMenu />
    </div>
  );
}