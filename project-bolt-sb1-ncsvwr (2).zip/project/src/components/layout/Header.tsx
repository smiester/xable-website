import React, { useState, useEffect } from 'react';
import { Menu, Home } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';
import { NavLink } from './NavLink';
import { MobileMenu } from './MobileMenu';
import { ResponsiveImage } from '../common/ResponsiveImage';
import { OPTIMIZED_IMAGES } from '../../constants/images';
import { getLogoSrcSet } from '../../utils/imageOptimization';

export function Header() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      const scrollPosition = window.scrollY;
      setIsScrolled(scrollPosition > 10);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleBookConsultation = () => {
    if (location.pathname !== '/') {
      window.location.href = '/#contact';
    } else {
      const contactSection = document.getElementById('contact');
      if (contactSection) {
        contactSection.scrollIntoView({ behavior: 'smooth' });
        const nameInput = document.querySelector('#name') as HTMLInputElement;
        if (nameInput) {
          nameInput.focus();
        }
      }
    }
  };

  const handleNavigation = (sectionId: string) => {
    if (location.pathname !== '/') {
      window.location.href = `/#${sectionId}`;
    } else {
      const section = document.getElementById(sectionId);
      if (section) {
        section.scrollIntoView({ behavior: 'smooth' });
      }
    }
  };

  return (
    <header 
      className={`fixed w-full top-0 z-40 transition-all duration-300 ${
        isScrolled 
          ? 'bg-white/80 backdrop-blur-md shadow-lg' 
          : 'bg-white/0'
      }`}
    >
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          <div className="flex items-center">
            <Link to="/" className="flex items-center">
              <picture>
                <source
                  type="image/webp"
                  srcSet={getLogoSrcSet(OPTIMIZED_IMAGES.logo)}
                  sizes="(max-width: 640px) 40px, 48px"
                />
                <img 
                  src={OPTIMIZED_IMAGES.logo.thumbnail}
                  alt="Xable Logo" 
                  width="40"
                  height="40"
                  className="h-10 w-10 rounded-lg shadow-lg"
                  loading="eager"
                  decoding="sync"
                />
              </picture>
              <span className={`ml-2 text-xl font-semibold transition-colors duration-300 ${
                isScrolled ? 'text-gray-900' : 'text-gray-800'
              }`}>Xable</span>
            </Link>
          </div>
          
          <div className="hidden md:flex items-center space-x-8">
            <Link 
              to="/" 
              className={`transition-colors duration-300 font-medium flex items-center gap-2 ${
                isScrolled ? 'text-gray-600 hover:text-purple-600' : 'text-gray-500 hover:text-purple-500'
              }`}
            >
              <Home className="w-4 h-4" />
              Home
            </Link>
            <button
              onClick={() => handleNavigation('services')}
              className={`transition-colors duration-300 font-medium ${
                isScrolled ? 'text-gray-600 hover:text-purple-600' : 'text-gray-500 hover:text-purple-500'
              }`}
            >
              Services
            </button>
            <button
              onClick={() => handleNavigation('approach')}
              className={`transition-colors duration-300 font-medium ${
                isScrolled ? 'text-gray-600 hover:text-purple-600' : 'text-gray-500 hover:text-purple-500'
              }`}
            >
              Our Approach
            </button>
            <button
              onClick={() => handleNavigation('team')}
              className={`transition-colors duration-300 font-medium ${
                isScrolled ? 'text-gray-600 hover:text-purple-600' : 'text-gray-500 hover:text-purple-500'
              }`}
            >
              Team
            </button>
            <Link 
              to="/blog" 
              className={`transition-colors duration-300 font-medium ${
                isScrolled ? 'text-gray-600 hover:text-purple-600' : 'text-gray-500 hover:text-purple-500'
              }`}
            >
              Blog
            </Link>
            <button
              onClick={() => handleNavigation('contact')}
              className={`transition-colors duration-300 font-medium ${
                isScrolled ? 'text-gray-600 hover:text-purple-600' : 'text-gray-500 hover:text-purple-500'
              }`}
            >
              Contact
            </button>
            <button 
              onClick={handleBookConsultation}
              className={`px-4 py-2 rounded-md transition-all duration-300 ${
                isScrolled
                  ? 'bg-purple-600 text-white hover:bg-purple-700'
                  : 'bg-purple-500 text-white hover:bg-purple-600'
              }`}
            >
              Book Consultation
            </button>
          </div>
          
          <button
            className="md:hidden"
            onClick={() => setIsMobileMenuOpen(true)}
            aria-label="Open menu"
          >
            <Menu className={`h-6 w-6 transition-colors duration-300 ${
              isScrolled ? 'text-gray-600' : 'text-gray-500'
            }`} />
          </button>
        </div>
      </nav>

      <MobileMenu 
        isOpen={isMobileMenuOpen} 
        setIsOpen={setIsMobileMenuOpen} 
        onBookConsultation={handleBookConsultation}
        onNavigation={handleNavigation}
      />
    </header>
  );
}