import React from 'react';

interface NavLinkProps {
  href: string;
  children: React.ReactNode;
  isScrolled?: boolean;
  onClick?: (e: React.MouseEvent<HTMLAnchorElement>) => void;
}

export function NavLink({ href, children, isScrolled, onClick }: NavLinkProps) {
  return (
    <a
      href={href}
      onClick={onClick}
      className={`transition-colors duration-300 font-medium ${
        isScrolled
          ? 'text-gray-600 hover:text-purple-600'
          : 'text-gray-500 hover:text-purple-500'
      }`}
    >
      {children}
    </a>
  );
}