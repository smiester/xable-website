import React from 'react';
import { Link } from 'react-router-dom';
import { format } from 'date-fns';
import { Calendar, User, Tag } from 'lucide-react';
import { Post } from '../../types/blog';

interface BlogCardProps {
  post: Post;
  featured?: boolean;
}

export function BlogCard({ post, featured = false }: BlogCardProps) {
  return (
    <article 
      className={`bg-white rounded-xl shadow-md overflow-hidden hover:shadow-xl transition-shadow duration-300 ${
        featured ? 'md:col-span-2 md:grid md:grid-cols-2 md:items-center' : ''
      }`}
    >
      {post.featuredImage && (
        <div className={`relative ${featured ? 'h-full' : 'h-48'}`}>
          <img 
            src={post.featuredImage} 
            alt={post.title}
            className="w-full h-full object-cover"
          />
          {featured && (
            <div className="absolute top-4 left-4">
              <span className="bg-purple-600 text-white px-3 py-1 rounded-full text-sm font-medium">
                Featured
              </span>
            </div>
          )}
        </div>
      )}
      <div className="p-6">
        <div className="flex items-center gap-4 text-sm text-gray-500 mb-3">
          <div className="flex items-center gap-1">
            <Calendar className="w-4 h-4" />
            <time dateTime={post.publishedAt.toISOString()}>
              {format(post.publishedAt, 'MMM d, yyyy')}
            </time>
          </div>
          <div className="flex items-center gap-1">
            <User className="w-4 h-4" />
            <span>{post.author}</span>
          </div>
        </div>
        
        <h2 className={`font-bold text-gray-900 mb-2 ${featured ? 'text-2xl' : 'text-xl'}`}>
          <Link to={`/blog/${post.slug}`} className="hover:text-purple-600 transition-colors">
            {post.title}
          </Link>
        </h2>
        
        <p className="text-gray-600 mb-4 line-clamp-2">{post.excerpt}</p>
        
        {post.tags.length > 0 && (
          <div className="flex items-center gap-2 flex-wrap">
            <Tag className="w-4 h-4 text-purple-600" />
            {post.tags.map((tag) => (
              <span
                key={tag}
                className="px-2 py-1 bg-purple-50 text-purple-600 text-xs rounded-full"
              >
                {tag}
              </span>
            ))}
          </div>
        )}
        
        <Link
          to={`/blog/${post.slug}`}
          className="inline-flex items-center mt-4 text-purple-600 hover:text-purple-700 font-medium"
        >
          Read more
          <svg className="w-4 h-4 ml-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M5 12h14M12 5l7 7-7 7" />
          </svg>
        </Link>
      </div>
    </article>
  );
}