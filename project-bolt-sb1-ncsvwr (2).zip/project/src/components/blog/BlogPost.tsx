import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { format } from 'date-fns';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '../../db/database';

export function BlogPost() {
  const { slug } = useParams();
  const navigate = useNavigate();
  
  const post = useLiveQuery(
    () => db.posts.where('slug').equals(slug || '').first()
  );

  if (!post) return <div>Loading...</div>;

  return (
    <article className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <header className="mb-8">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">{post.title}</h1>
        <div className="flex items-center justify-between text-gray-600">
          <div className="flex items-center space-x-4">
            <span>{post.author}</span>
            <time dateTime={post.publishedAt.toISOString()}>
              {format(post.publishedAt, 'MMMM d, yyyy')}
            </time>
          </div>
          <div className="flex gap-2">
            {post.tags.map((tag) => (
              <span
                key={tag}
                className="px-3 py-1 bg-purple-100 text-purple-800 rounded-full text-sm"
              >
                {tag}
              </span>
            ))}
          </div>
        </div>
      </header>

      {post.featuredImage && (
        <img
          src={post.featuredImage}
          alt={post.title}
          className="w-full h-96 object-cover rounded-lg mb-8"
        />
      )}

      <div 
        className="prose prose-purple max-w-none"
        dangerouslySetInnerHTML={{ __html: post.content }}
      />
    </article>
  );
}