import React, { useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { Search, Filter } from 'lucide-react';
import { blogService } from '../../services/blogService';
import { BlogCard } from './BlogCard';
import { BlogSkeleton } from './BlogSkeleton';
import { EmptyState } from './EmptyState';
import { FilterMenu } from './FilterMenu';

export function BlogList() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [isFilterOpen, setIsFilterOpen] = useState(false);

  const posts = useLiveQuery(() => blogService.getPublishedPosts());

  if (!posts) {
    return <BlogSkeleton />;
  }

  if (posts.length === 0) {
    return <EmptyState />;
  }

  const filteredPosts = posts.filter(post => {
    const matchesSearch = post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         post.excerpt.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesTags = selectedTags.length === 0 || 
                       selectedTags.some(tag => post.tags.includes(tag));
    return matchesSearch && matchesTags;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="mb-12">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">Blog</h1>
        <p className="text-xl text-gray-600">
          Insights and updates from our therapy practice
        </p>
      </div>

      <div className="flex flex-col sm:flex-row gap-4 mb-8">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <input
            type="search"
            placeholder="Search posts..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-purple-500 focus:border-purple-500"
          />
        </div>
        <button
          onClick={() => setIsFilterOpen(true)}
          className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-lg text-gray-700 bg-white hover:bg-gray-50"
        >
          <Filter className="w-5 h-5 mr-2" />
          Filter
        </button>
      </div>

      <FilterMenu
        isOpen={isFilterOpen}
        setIsOpen={setIsFilterOpen}
        selectedTags={selectedTags}
        setSelectedTags={setSelectedTags}
        availableTags={Array.from(new Set(posts.flatMap(post => post.tags)))}
      />

      <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
        {filteredPosts.map((post, index) => (
          <BlogCard 
            key={post.id} 
            post={post}
            featured={index === 0 && !searchTerm && selectedTags.length === 0}
          />
        ))}
      </div>

      {filteredPosts.length === 0 && (
        <div className="text-center py-12">
          <h3 className="text-lg font-medium text-gray-900 mb-2">No posts found</h3>
          <p className="text-gray-600">
            Try adjusting your search or filter criteria
          </p>
        </div>
      )}
    </div>
  );
}