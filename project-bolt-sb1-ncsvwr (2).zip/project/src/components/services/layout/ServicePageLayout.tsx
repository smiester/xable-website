import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, LucideIcon } from 'lucide-react';
import { useScrollToTop } from '../../../hooks/useScrollToTop';

interface ServicePageLayoutProps {
  title: string;
  icon: LucideIcon;
  heroImage: string;
  children: React.ReactNode;
}

export function ServicePageLayout({ title, icon: Icon, heroImage, children }: ServicePageLayoutProps) {
  useScrollToTop();

  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      <div className="relative h-64 bg-purple-600">
        <img
          src={heroImage}
          alt={title}
          className="w-full h-full object-cover mix-blend-overlay"
        />
        <div className="absolute inset-0 bg-purple-600/60" />
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center text-white">
            <Icon className="w-16 h-16 mx-auto mb-4" />
            <h1 className="text-4xl font-bold">{title}</h1>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <Link
          to="/"
          className="inline-flex items-center text-purple-600 hover:text-purple-700 mb-8"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Home
        </Link>

        <div className="bg-white rounded-lg shadow-lg p-8">
          {children}
        </div>
      </div>
    </div>
  );
}