import React from 'react';
import { ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';
import { ResponsiveImage } from '../../common/ResponsiveImage';
import { OptimizedImagePaths } from '../../../utils/imageOptimization';

interface ServiceLayoutProps {
  title: string;
  image: OptimizedImagePaths;
  imageAlt: string;
  children: React.ReactNode;
}

export function ServiceLayout({ title, image, imageAlt, children }: ServiceLayoutProps) {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <Link 
        to="/" 
        className="inline-flex items-center text-purple-600 hover:text-purple-700 mb-8"
      >
        <ArrowLeft className="h-4 w-4 mr-2" />
        Back to Home
      </Link>

      <div className="bg-white rounded-lg shadow-lg overflow-hidden">
        <ResponsiveImage
          sources={image}
          alt={imageAlt}
          className="w-full h-64 object-cover"
        />
        
        <div className="p-6 sm:p-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-6">
            {title}
          </h1>
          
          <div className="prose max-w-none">
            {children}
          </div>
        </div>
      </div>
    </div>
  );
}