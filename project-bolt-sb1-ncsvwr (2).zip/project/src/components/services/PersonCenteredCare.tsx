import React from 'react';
import { ServiceLayout } from './layout/ServiceLayout';
import { OPTIMIZED_IMAGES } from '../../constants/images';
import { serviceContent } from './content/serviceContent';

export function PersonCenteredCare() {
  const { title, content } = serviceContent.personCenteredCare;
  
  return (
    <ServiceLayout
      title={title}
      image={OPTIMIZED_IMAGES.approach.personCentered}
      imageAlt="Person-Centered Care"
    >
      {content.map((paragraph, index) => (
        <p key={index}>{paragraph}</p>
      ))}
    </ServiceLayout>
  );
}