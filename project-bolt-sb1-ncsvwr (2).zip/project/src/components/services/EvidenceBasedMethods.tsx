import React from 'react';
import { ServiceLayout } from './layout/ServiceLayout';
import { OPTIMIZED_IMAGES } from '../../constants/images';
import { serviceContent } from './content/serviceContent';

export function EvidenceBasedMethods() {
  const { title, content } = serviceContent.evidenceBasedMethods;
  
  return (
    <ServiceLayout
      title={title}
      image={OPTIMIZED_IMAGES.approach.evidenceBased}
      imageAlt="Evidence-Based Methods"
    >
      {content.map((paragraph, index) => (
        <p key={index}>{paragraph}</p>
      ))}
    </ServiceLayout>
  );
}