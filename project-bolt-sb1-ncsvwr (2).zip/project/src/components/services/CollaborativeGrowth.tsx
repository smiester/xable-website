import React from 'react';
import { ServiceLayout } from './layout/ServiceLayout';
import { OPTIMIZED_IMAGES } from '../../constants/images';
import { serviceContent } from './content/serviceContent';

export function CollaborativeGrowth() {
  const { title, content } = serviceContent.collaborativeGrowth;
  
  return (
    <ServiceLayout
      title={title}
      image={OPTIMIZED_IMAGES.approach.collaborative}
      imageAlt="Collaborative Growth"
    >
      {content.map((paragraph, index) => (
        <p key={index}>{paragraph}</p>
      ))}
    </ServiceLayout>
  );
}