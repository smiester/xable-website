export const serviceContent = {
  personCenteredCare: {
    title: "Person-Centered Care in Applied Behavior Analysis (ABA)",
    content: [
      "As an OAP provider, our Person-Centered Care approach in Applied Behavior Analysis (ABA) represents a fundamental shift in autism therapy. We recognize that each individual has unique needs, preferences, and learning styles that require personalized intervention strategies.",
      "Through comprehensive behavioral assessments and Intensive Behavioural Intervention (IBI), we develop individualized treatment plans that consider environmental factors, motivations, and personal characteristics. Our Core Clinical Services integrate speech and language therapy, occupational therapy, and social skills development to create a holistic support system.",
      "This approach ensures that ABA techniques respect individual autonomy while promoting skill development through Foundational Family Services and Entry to School Programs. We continuously adjust our strategies based on progress and feedback, maintaining a flexible and responsive treatment plan that evolves with the individual's needs."
    ]
  },
  evidenceBasedMethods: {
    title: "Evidence-Based Methods in ABA Therapy",
    content: [
      "Our commitment to evidence-based methods in ABA therapy ensures that every intervention is grounded in scientific research and proven therapeutic techniques. As an Ontario Autism Program (OAP) provider, we integrate the latest findings in behavioral science with established ABA principles.",
      "Our comprehensive approach includes Core Clinical Services, Caregiver-Mediated Early Years (CMEY) Programs, and Urgent Response Services. We utilize validated assessment tools and measurement systems to track behavioral changes and skill acquisition, ensuring that our methods are both effective and empirically supported.",
      "Through continuous monitoring and data collection, we maintain the highest standards in ABA therapy, speech and language therapy, and occupational therapy. This scientific approach allows us to provide interventions that are not only effective but also ethically sound and professionally validated."
    ]
  },
  collaborativeGrowth: {
    title: "Collaborative Growth in Autism Support",
    content: [
      "Our Collaborative Growth approach emphasizes the importance of partnership in autism therapy. As an OAP provider, we work closely with families through our Foundational Family Services, offering comprehensive support including respite care services and family support programs.",
      "This collaborative model integrates Core Clinical Services with caregiver training, ensuring that ABA therapy strategies are effectively implemented across all environments. We provide specialized support through our Entry to School Program and Social Skills Groups, creating opportunities for peer interaction and skill development.",
      "By fostering strong partnerships between therapists, families, and other healthcare providers, we create a consistent and supportive environment that promotes lasting behavioral change. Our team-based approach ensures that strategies learned in therapy sessions are successfully transferred to daily life situations."
    ]
  }
};