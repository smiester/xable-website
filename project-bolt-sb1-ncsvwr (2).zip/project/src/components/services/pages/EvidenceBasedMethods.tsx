import React from 'react';
import { ServicePageLayout } from '../layout/ServicePageLayout';
import { Microscope } from 'lucide-react';

export function EvidenceBasedMethods() {
  return (
    <ServicePageLayout
      title="Evidence-Based Methods"
      icon={Microscope}
      heroImage="https://images.unsplash.com/photo-1516627145497-ae6968895b74"
    >
      <div className="prose max-w-none">
        <p className="lead">
          Our commitment to evidence-based practices ensures that every intervention we provide
          is grounded in scientific research and proven therapeutic techniques.
        </p>

        <h2>Research-Backed Approaches</h2>
        <ul>
          <li>Applied Behavior Analysis (ABA)</li>
          <li>Cognitive Behavioral Therapy (CBT)</li>
          <li>Speech and Language Pathology</li>
          <li>Occupational Therapy</li>
          <li>Social Skills Training</li>
        </ul>

        <h2>Quality Assurance</h2>
        <p>
          We maintain rigorous standards in our therapeutic practices through continuous
          data collection, progress monitoring, and outcome measurement. This systematic
          approach allows us to make informed decisions about treatment modifications
          and ensure optimal results.
        </p>

        <h2>Key Benefits</h2>
        <ul>
          <li>Proven effectiveness through research</li>
          <li>Measurable progress tracking</li>
          <li>Data-driven decision making</li>
          <li>Consistent quality of care</li>
          <li>Optimal therapeutic outcomes</li>
        </ul>
      </div>
    </ServicePageLayout>
  );
}