import React from 'react';
import { ServicePageLayout } from '../layout/ServicePageLayout';
import { Users } from 'lucide-react';

export function GroupSessions() {
  return (
    <ServicePageLayout
      title="Small Group Sessions"
      icon={Users}
      heroImage="https://images.unsplash.com/photo-1529390079861-591de354faf5"
    >
      <div className="prose max-w-none">
        <p className="lead">
          Our small group sessions create supportive environments where participants can
          practice social skills and learn from peer interactions.
        </p>

        <h2>Session Structure</h2>
        <ul>
          <li>4-6 participants per group</li>
          <li>Age-appropriate activities</li>
          <li>Structured social interactions</li>
          <li>Guided peer learning</li>
          <li>Skill practice opportunities</li>
        </ul>

        <h2>Learning Environment</h2>
        <p>
          Groups are carefully structured to promote positive interactions while providing
          individual support as needed. Activities are designed to be engaging, meaningful,
          and developmentally appropriate.
        </p>

        <h2>Key Benefits</h2>
        <ul>
          <li>Natural social skill development</li>
          <li>Peer relationship building</li>
          <li>Increased confidence</li>
          <li>Real-world practice</li>
          <li>Community integration</li>
        </ul>
      </div>
    </ServicePageLayout>
  );
}