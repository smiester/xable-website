import React from 'react';
import { ServicePageLayout } from '../layout/ServicePageLayout';
import { UserPlus } from 'lucide-react';

export function SocialSkills() {
  return (
    <ServicePageLayout
      title="Social Skills Development"
      icon={UserPlus}
      heroImage="https://images.unsplash.com/photo-1543269664-76bc3997d9ea"
    >
      <div className="prose max-w-none">
        <p className="lead">
          Our social skills program helps individuals develop the confidence and competence
          needed for successful social interactions and relationship building.
        </p>

        <h2>Core Skills</h2>
        <ul>
          <li>Conversation skills</li>
          <li>Non-verbal communication</li>
          <li>Emotional recognition</li>
          <li>Perspective taking</li>
          <li>Problem-solving</li>
        </ul>

        <h2>Teaching Methods</h2>
        <p>
          We use a combination of direct instruction, role-playing, and naturalistic
          teaching to help individuals learn and practice social skills in a supportive
          environment.
        </p>

        <h2>Program Benefits</h2>
        <ul>
          <li>Better social understanding</li>
          <li>Improved peer relationships</li>
          <li>Enhanced communication</li>
          <li>Greater self-confidence</li>
          <li>Reduced social anxiety</li>
        </ul>
      </div>
    </ServicePageLayout>
  );
}