import React from 'react';
import { ServicePageLayout } from '../layout/ServicePageLayout';
import { Briefcase } from 'lucide-react';

export function LifeSkills() {
  return (
    <ServicePageLayout
      title="Life Skills Development"
      icon={Briefcase}
      heroImage="https://images.unsplash.com/photo-1450101499163-c8848c66ca85"
    >
      <div className="prose max-w-none">
        <p className="lead">
          Our life skills program focuses on developing practical skills essential for
          daily living and increasing independence.
        </p>

        <h2>Key Areas</h2>
        <ul>
          <li>Personal care and hygiene</li>
          <li>Home management skills</li>
          <li>Time management</li>
          <li>Money management</li>
          <li>Community navigation</li>
        </ul>

        <h2>Teaching Approach</h2>
        <p>
          Skills are taught through hands-on practice, task analysis, and systematic
          instruction. We create opportunities for learning in both structured and
          natural environments to promote skill generalization.
        </p>

        <h2>Expected Outcomes</h2>
        <ul>
          <li>Greater self-sufficiency</li>
          <li>Improved daily living skills</li>
          <li>Enhanced decision-making</li>
          <li>Better self-advocacy</li>
          <li>Increased independence</li>
        </ul>
      </div>
    </ServicePageLayout>
  );
}