import React from 'react';
import { ServicePageLayout } from '../layout/ServicePageLayout';
import { Heart } from 'lucide-react';

export function PersonCenteredCare() {
  return (
    <ServicePageLayout
      title="Person-Centered Care"
      icon={Heart}
      heroImage="https://images.unsplash.com/photo-1603354350317-6f7aaa5911c5"
    >
      <div className="prose max-w-none">
        <p className="lead">
          Our person-centered approach recognizes that every individual is unique, with their own
          strengths, challenges, and goals. We tailor our therapeutic interventions to match each
          person's specific needs and learning style.
        </p>

        <h2>Key Components</h2>
        <ul>
          <li>Individualized assessment and goal setting</li>
          <li>Customized therapy plans</li>
          <li>Regular progress monitoring and plan adjustment</li>
          <li>Integration of personal interests and preferences</li>
          <li>Focus on meaningful, functional outcomes</li>
        </ul>

        <h2>Our Process</h2>
        <p>
          We begin with a comprehensive assessment to understand each person's unique profile,
          including their strengths, challenges, interests, and goals. This information guides
          the development of a customized therapy plan that aligns with individual needs and
          family priorities.
        </p>

        <h2>Benefits</h2>
        <ul>
          <li>Higher engagement and motivation</li>
          <li>More effective skill development</li>
          <li>Better generalization of learned skills</li>
          <li>Increased confidence and independence</li>
          <li>Stronger therapeutic relationships</li>
        </ul>
      </div>
    </ServicePageLayout>
  );
}