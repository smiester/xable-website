import React from 'react';
import { ServicePageLayout } from '../layout/ServicePageLayout';
import { GraduationCap } from 'lucide-react';

export function CaregiverTraining() {
  return (
    <ServicePageLayout
      title="Caregiver Training"
      icon={GraduationCap}
      heroImage="https://images.unsplash.com/photo-1516627145497-ae6968895b74"
    >
      <div className="prose max-w-none">
        <p className="lead">
          Our comprehensive caregiver training program empowers families with knowledge,
          strategies, and practical tools to support their loved ones effectively.
        </p>

        <h2>Training Components</h2>
        <ul>
          <li>ABA principles and techniques</li>
          <li>Behavior management strategies</li>
          <li>Communication enhancement</li>
          <li>Crisis prevention</li>
          <li>Progress monitoring</li>
        </ul>

        <h2>Support Structure</h2>
        <p>
          We provide ongoing guidance through workshops, coaching sessions, and
          hands-on practice. Our approach ensures caregivers feel confident in
          implementing strategies across different settings.
        </p>

        <h2>Program Benefits</h2>
        <ul>
          <li>Enhanced caregiving skills</li>
          <li>Better understanding of ABA</li>
          <li>Improved family dynamics</li>
          <li>Consistent support strategies</li>
          <li>Greater confidence</li>
        </ul>
      </div>
    </ServicePageLayout>
  );
}