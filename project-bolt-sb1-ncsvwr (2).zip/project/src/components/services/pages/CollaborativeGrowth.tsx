import React from 'react';
import { ServicePageLayout } from '../layout/ServicePageLayout';
import { Users } from 'lucide-react';

export function CollaborativeGrowth() {
  return (
    <ServicePageLayout
      title="Collaborative Growth"
      icon={Users}
      heroImage="https://images.unsplash.com/photo-1582213782179-e0d53f98f2ca"
    >
      <div className="prose max-w-none">
        <p className="lead">
          Our collaborative approach brings together therapists, families, and other care
          providers to create a comprehensive support system that promotes lasting positive
          change.
        </p>

        <h2>Partnership Elements</h2>
        <ul>
          <li>Family-centered planning</li>
          <li>Multi-disciplinary team coordination</li>
          <li>Regular progress updates and consultation</li>
          <li>Shared decision-making</li>
          <li>Integrated support strategies</li>
        </ul>

        <h2>Team Approach</h2>
        <p>
          We believe that the best outcomes are achieved when everyone involved in an
          individual's care works together. Our collaborative model ensures consistent
          support across all environments and promotes skill generalization through
          coordinated efforts.
        </p>

        <h2>Expected Outcomes</h2>
        <ul>
          <li>Consistent support across environments</li>
          <li>Better skill generalization</li>
          <li>Enhanced family engagement</li>
          <li>Improved communication between providers</li>
          <li>More effective intervention strategies</li>
        </ul>
      </div>
    </ServicePageLayout>
  );
}