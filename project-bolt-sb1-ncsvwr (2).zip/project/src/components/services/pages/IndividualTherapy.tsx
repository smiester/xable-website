import React from 'react';
import { ServicePageLayout } from '../layout/ServicePageLayout';
import { UserCheck } from 'lucide-react';

export function IndividualTherapy() {
  return (
    <ServicePageLayout
      title="Individual Therapy"
      icon={UserCheck}
      heroImage="https://images.unsplash.com/photo-1576765608535-5f04d1e3f289"
    >
      <div className="prose max-w-none">
        <p className="lead">
          Our individual therapy sessions provide one-on-one support tailored to each person's
          unique needs, goals, and learning style.
        </p>

        <h2>Program Features</h2>
        <ul>
          <li>Personalized ABA therapy programs</li>
          <li>Customized learning strategies</li>
          <li>Skill-based interventions</li>
          <li>Progress tracking and assessment</li>
          <li>Regular parent consultation</li>
        </ul>

        <h2>Areas of Focus</h2>
        <p>
          Each session targets specific developmental areas based on individual needs,
          including communication, behavior management, social skills, daily living skills,
          and academic readiness.
        </p>

        <h2>Expected Outcomes</h2>
        <ul>
          <li>Enhanced communication abilities</li>
          <li>Improved behavioral regulation</li>
          <li>Greater independence</li>
          <li>Better social interaction</li>
          <li>Strengthened learning skills</li>
        </ul>
      </div>
    </ServicePageLayout>
  );
}