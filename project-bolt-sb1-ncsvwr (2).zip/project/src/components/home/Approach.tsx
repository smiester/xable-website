import React from 'react';
import { fadeIn, staggerChildren } from '../../utils/animation';
import { ApproachHeader } from './approach/ApproachHeader';
import { ApproachGrid } from './approach/ApproachGrid';
import { useApproachVisibility } from './approach/useApproachVisibility';

export function Approach() {
  const isVisible = useApproachVisibility();

  return (
    <div id="approach" className="bg-purple-50 py-12 sm:py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <ApproachHeader isVisible={isVisible} fadeIn={fadeIn} />
        <div className="mt-12 sm:mt-20">
          <ApproachGrid 
            isVisible={isVisible} 
            fadeIn={fadeIn} 
            staggerChildren={staggerChildren} 
          />
        </div>
      </div>
    </div>
  );
}