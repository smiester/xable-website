import React from 'react';
import { Link } from 'react-router-dom';
import { useLiveQuery } from 'dexie-react-hooks';
import { ArrowRight } from 'lucide-react';
import { blogService } from '../../services/blogService';
import { BlogCard } from '../blog/BlogCard';

export function BlogSection() {
  const posts = useLiveQuery(() => 
    blogService.getPublishedPosts().then(posts => posts.slice(0, 3))
  );

  if (!posts || posts.length === 0) return null;

  return (
    <section id="blog" className="py-12 sm:py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 sm:text-4xl">
            Latest Insights
          </h2>
          <p className="mt-4 text-xl text-gray-600">
            Stay updated with our latest articles and resources
          </p>
        </div>

        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3 mb-12">
          {posts.map((post, index) => (
            <BlogCard 
              key={post.id} 
              post={post}
              featured={index === 0}
            />
          ))}
        </div>

        <div className="text-center">
          <Link
            to="/blog"
            className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-purple-600 hover:bg-purple-700 transition-colors"
          >
            View All Posts
            <ArrowRight className="ml-2 h-5 w-5" />
          </Link>
        </div>
      </div>
    </section>
  );
}