import { Heart, Users, UserPlus, Briefcase, GraduationCap } from 'lucide-react';

export const services = [
  {
    title: 'Individualised Therapy',
    description: 'Personalized sessions focused on individual growth and development.',
    icon: Heart,
    link: '/services/individual-therapy'
  },
  {
    title: 'Small Group Sessions',
    description: 'Safe spaces for social interaction and peer support.',
    icon: Users,
    link: '/services/group-sessions'
  },
  {
    title: 'Social Skills',
    description: 'Building confidence and competence in social interactions.',
    icon: UserPlus,
    link: '/services/social-skills'
  },
  {
    title: 'Life Skills',
    description: 'Developing essential daily living and independence skills.',
    icon: Briefcase,
    link: '/services/life-skills'
  },
  {
    title: 'Caregiver Training',
    description: 'Empowering families with strategies and tools for continued support at home.',
    icon: GraduationCap,
    link: '/services/caregiver-training'
  },
];