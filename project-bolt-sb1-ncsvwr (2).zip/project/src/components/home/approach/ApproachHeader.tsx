import React from 'react';

interface ApproachHeaderProps {
  isVisible: boolean;
  fadeIn: string;
}

export function ApproachHeader({ isVisible, fadeIn }: ApproachHeaderProps) {
  return (
    <div className={`lg:text-center ${isVisible ? fadeIn : 'opacity-0'}`}>
      <h2 className="text-2xl sm:text-3xl font-extrabold text-gray-900 sm:text-4xl">
        Our Therapeutic Approach
      </h2>
      <p className="mt-4 max-w-2xl text-lg sm:text-xl text-gray-500 lg:mx-auto">
        We believe in creating a supportive environment that celebrates diversity and promotes personal growth.
      </p>
    </div>
  );
}