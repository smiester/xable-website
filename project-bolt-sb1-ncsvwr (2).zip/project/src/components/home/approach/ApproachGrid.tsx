import React from 'react';
import { ApproachCard } from './ApproachCard';
import { OPTIMIZED_IMAGES } from '../../../constants/images';

interface ApproachGridProps {
  isVisible: boolean;
  fadeIn: string;
  staggerChildren: (index: number) => { style: { animationDelay: string } };
}

export function ApproachGrid({ isVisible, fadeIn, staggerChildren }: ApproachGridProps) {
  const approaches = [
    {
      image: OPTIMIZED_IMAGES.approach.personCentered,
      title: "Person-Centered Care",
      description: "Every individual is unique. We tailor our approach to match your specific needs, strengths, and goals.",
      link: "/services/person-centered-care"
    },
    {
      image: OPTIMIZED_IMAGES.approach.evidenceBased,
      title: "Evidence-Based Methods",
      description: "Our practices are grounded in research and proven therapeutic techniques, ensuring effective support.",
      link: "/services/evidence-based-methods"
    },
    {
      image: OPTIMIZED_IMAGES.approach.collaborative,
      title: "Collaborative Growth",
      description: "We work together with clients and families to create meaningful progress and lasting positive change.",
      link: "/services/collaborative-growth"
    }
  ];

  return (
    <div className="grid grid-cols-1 gap-6 sm:gap-12 lg:grid-cols-3">
      {approaches.map((item, index) => (
        <ApproachCard
          key={item.title}
          {...item}
          index={index}
          isVisible={isVisible}
          staggerChildren={staggerChildren}
          fadeIn={fadeIn}
        />
      ))}
    </div>
  );
}