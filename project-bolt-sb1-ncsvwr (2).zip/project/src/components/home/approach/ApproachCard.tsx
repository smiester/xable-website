import React from 'react';
import { Link } from 'react-router-dom';
import { ResponsiveImage } from '../../common/ResponsiveImage';
import { OptimizedImagePaths } from '../../../utils/imageOptimization';

interface ApproachCardProps {
  title: string;
  description: string;
  image: OptimizedImagePaths;
  index: number;
  isVisible: boolean;
  staggerChildren: (index: number) => { style: { animationDelay: string } };
  fadeIn: string;
  link?: string;
}

export function ApproachCard({
  title,
  description,
  image,
  index,
  isVisible,
  staggerChildren,
  fadeIn,
  link,
}: ApproachCardProps) {
  const CardWrapper = link ? Link : 'div';
  const props = link ? { to: link } : {};

  return (
    <CardWrapper
      {...props}
      className={`bg-white rounded-lg shadow-lg overflow-hidden transform transition-all duration-300 hover:scale-105 ${
        isVisible ? fadeIn : 'opacity-0'
      } ${link ? 'cursor-pointer' : ''}`}
      {...staggerChildren(index)}
    >
      <div className="relative h-48">
        <ResponsiveImage
          sources={image}
          alt={title}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
      </div>
      <div className="p-6">
        <h3 className="text-lg font-medium text-purple-600">{title}</h3>
        <p className="mt-4 text-gray-500">{description}</p>
      </div>
    </CardWrapper>
  );
}