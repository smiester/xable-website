import { useState, useEffect } from 'react';
import { authService, User } from '../services/authService';

export function useAuth() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const verifyAuth = async () => {
      const token = authService.getToken();
      if (token) {
        const user = await authService.verifyToken(token);
        setUser(user);
      }
      setLoading(false);
    };

    verifyAuth();
  }, []);

  const login = async (username: string, password: string) => {
    const token = await authService.login(username, password);
    localStorage.setItem('auth_token', token);
    const user = await authService.verifyToken(token);
    setUser(user);
    return user;
  };

  const logout = async () => {
    if (user?.sessionId) {
      await authService.logout(user.sessionId);
    }
    setUser(null);
  };

  return { user, loading, login, logout };
}