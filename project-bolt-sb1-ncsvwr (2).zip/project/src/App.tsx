import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { PublicLayout } from './components/layout/PublicLayout';
import { BlogList } from './components/blog/BlogList';
import { BlogPost } from './components/blog/BlogPost';
import { PostForm } from './components/admin/PostForm';
import { AdminBlogList } from './components/admin/AdminBlogList';
import { LoginPage } from './components/auth/LoginPage';
import { ProtectedRoute } from './components/auth/ProtectedRoute';
import { AuthProvider } from './context/AuthContext';
import { IndividualTherapy } from './components/services/pages/IndividualTherapy';
import { GroupSessions } from './components/services/pages/GroupSessions';
import { SocialSkills } from './components/services/pages/SocialSkills';
import { LifeSkills } from './components/services/pages/LifeSkills';
import { CaregiverTraining } from './components/services/pages/CaregiverTraining';
import { PersonCenteredCare } from './components/services/pages/PersonCenteredCare';
import { EvidenceBasedMethods } from './components/services/pages/EvidenceBasedMethods';
import { CollaborativeGrowth } from './components/services/pages/CollaborativeGrowth';

export default function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          <Route path="/" element={<PublicLayout />}>
            <Route path="blog" element={<BlogList />} />
            <Route path="blog/:slug" element={<BlogPost />} />
            <Route path="services/individual-therapy" element={<IndividualTherapy />} />
            <Route path="services/group-sessions" element={<GroupSessions />} />
            <Route path="services/social-skills" element={<SocialSkills />} />
            <Route path="services/life-skills" element={<LifeSkills />} />
            <Route path="services/caregiver-training" element={<CaregiverTraining />} />
            <Route path="services/person-centered-care" element={<PersonCenteredCare />} />
            <Route path="services/evidence-based-methods" element={<EvidenceBasedMethods />} />
            <Route path="services/collaborative-growth" element={<CollaborativeGrowth />} />
            <Route path="login" element={<LoginPage />} />
            <Route
              path="admin/posts"
              element={
                <ProtectedRoute>
                  <AdminBlogList />
                </ProtectedRoute>
              }
            />
            <Route
              path="admin/posts/new"
              element={
                <ProtectedRoute>
                  <PostForm />
                </ProtectedRoute>
              }
            />
            <Route
              path="admin/posts/:id/edit"
              element={
                <ProtectedRoute>
                  <PostForm />
                </ProtectedRoute>
              }
            />
          </Route>
        </Routes>
      </Router>
    </AuthProvider>
  );
}