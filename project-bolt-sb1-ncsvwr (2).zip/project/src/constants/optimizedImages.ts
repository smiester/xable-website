// Auto-generated optimized image paths
export const OPTIMIZED_IMAGES = {
  logo: {
    thumbnail: "/images/logo-thumbnail.webp",
    small: "/images/logo-small.webp",
    medium: "/images/logo-medium.webp",
    large: "/images/logo-large.webp"
  },
  hero: {
    thumbnail: "/images/hero-thumbnail.webp",
    small: "/images/hero-small.webp",
    medium: "/images/hero-medium.webp",
    large: "/images/hero-large.webp"
  },
  approach: {
    personCentered: {
      thumbnail: "/images/approach-personCentered-thumbnail.webp",
      small: "/images/approach-personCentered-small.webp",
      medium: "/images/approach-personCentered-medium.webp",
      large: "/images/approach-personCentered-large.webp"
    },
    evidenceBased: {
      thumbnail: "/images/approach-evidenceBased-thumbnail.webp",
      small: "/images/approach-evidenceBased-small.webp",
      medium: "/images/approach-evidenceBased-medium.webp",
      large: "/images/approach-evidenceBased-large.webp"
    },
    collaborative: {
      thumbnail: "/images/approach-collaborative-thumbnail.webp",
      small: "/images/approach-collaborative-small.webp",
      medium: "/images/approach-collaborative-medium.webp",
      large: "/images/approach-collaborative-large.webp"
    }
  },
  team: {
    therapist: {
      thumbnail: "/images/team-therapist-thumbnail.webp",
      small: "/images/team-therapist-small.webp",
      medium: "/images/team-therapist-medium.webp",
      large: "/images/team-therapist-large.webp"
    }
  }
};