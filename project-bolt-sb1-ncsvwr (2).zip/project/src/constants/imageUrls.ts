// Base Unsplash URLs for approach section images
export const APPROACH_IMAGE_URLS = {
  personCentered: "https://images.unsplash.com/photo-1603354350317-6f7aaa5911c5", // Child therapy session
  evidenceBased: "https://images.unsplash.com/photo-1516627145497-ae6968895b74", // Clinical setting
  collaborative: "https://images.unsplash.com/photo/1516627145497-ae6968895b74/tuTMECjFBdk" // Children with special needs
};